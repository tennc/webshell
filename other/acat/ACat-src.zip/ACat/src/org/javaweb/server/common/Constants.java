package org.javaweb.server.common;

public class Constants {
	
	public static final String SYS_CONFIG_VERSION = "z7y-zsy-WebServer-1.0";
	
	public static final String SYS_CONFIG_NAME = "z7y-server";
	
}
