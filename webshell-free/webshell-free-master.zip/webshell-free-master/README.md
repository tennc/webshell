# webshell-free
![visitor badge](https://visitor-badge.glitch.me/badge?page_id=https://github.com/rexSurprise/webshell-free.git)
## ！！！声明！！！

**本程序仅供于学习交流，请使用者遵守《中华人民共和国网络安全法》，勿将此脚本用于非授权的测试，脚本开发者不负任何连带法律责任。**



webshell免杀案例



包含大佬开发的项目

✅ [JSP-Webshells](https://github.com/threedr3am/JSP-WebShells)

✅ [webshell-venom](https://github.com/yzddmr6/webshell-venom)



