code = """
    private byte[] decoder(String payload) {
        return payload.getBytes();
    }
"""