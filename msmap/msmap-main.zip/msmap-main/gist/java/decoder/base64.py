code = """
    private byte[] decoder(String payload) {
        return b64decode(payload);
    }
"""